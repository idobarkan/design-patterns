﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FaceBookBackEnd
{
    public enum eRecommendationSource
	{
	    Checkins,
        Photos,
        Events,
	}
}
