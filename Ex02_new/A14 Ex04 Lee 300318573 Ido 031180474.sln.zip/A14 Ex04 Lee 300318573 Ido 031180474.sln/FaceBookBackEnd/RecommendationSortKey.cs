﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FaceBookBackEnd
{
    public enum eRecommendationSortKey
    {
        CreateTime,
        Likes,
        Comments,
        StartTime,
        AttendingUsers,
        WallPosts,
        UpdateTime,
        Tags,
        None,
    }
}
