﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FindTagsAround
{
    public class GoogleMapsReference
    {
        public string Reference
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }
    }
}
